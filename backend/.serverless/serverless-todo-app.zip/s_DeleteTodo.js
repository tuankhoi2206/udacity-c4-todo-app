
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'tuankhoi2206',
  applicationName: 'khoivt1',
  appUid: 'PF8MVhpX2zkypXzY4s',
  orgUid: 'b536539a-49db-4744-b2cd-593f5adb8b7d',
  deploymentUid: '304d8531-86e2-4846-b2bb-04dbcd72ff37',
  serviceName: 'serverless-todo-app',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-todo-app-dev-DeleteTodo', timeout: 6 };

try {
  const userHandler = require('./src/lambda/http/deleteTodo.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}